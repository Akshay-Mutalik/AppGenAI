-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: prompt_framework_new
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `recipe`
--

DROP TABLE IF EXISTS `recipe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recipe` (
  `recipeID` varchar(30) NOT NULL,
  `roleID` varchar(30) DEFAULT NULL,
  `commandID` varchar(30) DEFAULT NULL,
  `topicID` varchar(30) DEFAULT NULL,
  `contextID` varchar(30) DEFAULT NULL,
  `targetaudienceID` varchar(30) DEFAULT NULL,
  `outputformatID` varchar(30) DEFAULT NULL,
  `outputstructureID` varchar(30) DEFAULT NULL,
  `outputqualityID` varchar(30) DEFAULT NULL,
  `inputfilterID` varchar(30) DEFAULT NULL,
  `outputfilterID` varchar(30) DEFAULT NULL,
  `contextfilterID` varchar(30) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`recipeID`),
  KEY `roleID` (`roleID`),
  KEY `commandID` (`commandID`),
  KEY `topicID` (`topicID`),
  KEY `contextID` (`contextID`),
  KEY `targetaudienceID` (`targetaudienceID`),
  KEY `outputformatID` (`outputformatID`),
  KEY `outputstructureID` (`outputstructureID`),
  KEY `outputqualityID` (`outputqualityID`),
  KEY `inputfilterID` (`inputfilterID`),
  KEY `outputfilterID` (`outputfilterID`),
  KEY `contextfilterID` (`contextfilterID`),
  CONSTRAINT `recipe_ibfk_1` FOREIGN KEY (`roleID`) REFERENCES `role` (`roleID`),
  CONSTRAINT `recipe_ibfk_10` FOREIGN KEY (`outputfilterID`) REFERENCES `outputfilter` (`outputfilterID`),
  CONSTRAINT `recipe_ibfk_11` FOREIGN KEY (`contextfilterID`) REFERENCES `contextfilter` (`contextfilterID`),
  CONSTRAINT `recipe_ibfk_2` FOREIGN KEY (`commandID`) REFERENCES `command` (`commandID`),
  CONSTRAINT `recipe_ibfk_3` FOREIGN KEY (`topicID`) REFERENCES `topic` (`topicID`),
  CONSTRAINT `recipe_ibfk_4` FOREIGN KEY (`contextID`) REFERENCES `contextfilter` (`contextfilterID`),
  CONSTRAINT `recipe_ibfk_5` FOREIGN KEY (`targetaudienceID`) REFERENCES `targetaudience` (`targetaudienceID`),
  CONSTRAINT `recipe_ibfk_6` FOREIGN KEY (`outputformatID`) REFERENCES `outputformat` (`outputformatID`),
  CONSTRAINT `recipe_ibfk_7` FOREIGN KEY (`outputstructureID`) REFERENCES `outputstructure` (`outputstructureID`),
  CONSTRAINT `recipe_ibfk_8` FOREIGN KEY (`outputqualityID`) REFERENCES `outputquality` (`outputqualityID`),
  CONSTRAINT `recipe_ibfk_9` FOREIGN KEY (`inputfilterID`) REFERENCES `inputfilter` (`inputfilterID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recipe`
--

LOCK TABLES `recipe` WRITE;
/*!40000 ALTER TABLE `recipe` DISABLE KEYS */;
INSERT INTO `recipe` VALUES ('Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty',' '),('Test Cases','Test Engineer','Test case','Hue','1','Tester','Excel','Excel','1','1','1','1',' Test case generation');
/*!40000 ALTER TABLE `recipe` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-03  6:01:03
